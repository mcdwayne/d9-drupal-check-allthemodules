import cv2
import PIL
from PIL import Image
import os
import time
import sys
import face_recognition


def facedetectioncrop(image, requiredw, requiredh, extension, directorytosave,  currentfoldername,imagename):
	# acedata = haracascadepath
	# cascade = cv2.CascadeClassifier(facedata)

	print(' required width '+str(requiredw))

	print(' required height '+str(requiredh))

	imagetoberesized = Image.open(image)

	wpercent = ((requiredw + 100) / float(imagetoberesized.size[0]))
	hsize = int((float(imagetoberesized.size[1]) * float(wpercent)))

	#some time height is not big following login has to be done
	apectratioHeight = 100
	while  (hsize < requiredh):
		apectratioHeight +=50
		wpercent = ((requiredw + apectratioHeight) / float(imagetoberesized.size[0]))
		hsize = int((float(imagetoberesized.size[1]) * float(wpercent)))

	resizedimage = imagetoberesized.resize((requiredw + 100, hsize), PIL.Image.ANTIALIAS)

	resizedimage.save(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension, quality=95)

	img = cv2.imread(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)
	# img = cv2.imread(resizedimage)

	# minisize = (img.shape[1],img.shape[0])
	# miniframe = cv2.resize(img, minisize)
	# width, height = cv2.GetSize(src)
	height = img.shape[0]
	width = img.shape[1]

	# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	# faces = cascade.detectMultiScale(gray,scaleFactor=1.1, minNeighbors=5, minSize=(15, 15), flags = cv2.CASCADE_SCALE_IMAGE)
	# if (os.path.isfile(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)):
	#    print(' file exists')


	imagedeepneural = face_recognition.load_image_file(
		directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)
	# Find all the faces in the image using the default HOG-based model.
	# This method is fairly accurate, but not as accurate as the CNN model and not GPU accelerated.
	# See also: find_faces_in_picture_cnn.py
	faces = face_recognition.face_locations(imagedeepneural, number_of_times_to_upsample=1, model="cnn")

	# if there are more faces then reduce the additional width by 70
	if len(faces) >= 3:
		print('image lenght more then 3')
		wpercent = ((requiredw + 65) / float(imagetoberesized.size[0]))
		hsize = int((float(imagetoberesized.size[1]) * float(wpercent)))

		apectratioHeight = 65
		while (hsize < requiredh):
			apectratioHeight += 30
			wpercent = ((requiredw + apectratioHeight) / float(imagetoberesized.size[0]))
			hsize = int((float(imagetoberesized.size[1]) * float(wpercent)))



		resizedimage = imagetoberesized.resize((requiredw + 65, hsize), PIL.Image.ANTIALIAS)

		resizedimage.save(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension,
						  quality=95)

		img = cv2.imread(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)
		# img = cv2.imread(resizedimage)

		# minisize = (img.shape[1],img.shape[0])
		# miniframe = cv2.resize(img, minisize)
		# width, height = cv2.GetSize(src)
		height = img.shape[0]
		width = img.shape[1]

		# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		# faces = cascade.detectMultiScale(gray,scaleFactor=1.1, minNeighbors=5, minSize=(15, 15), flags = cv2.CASCADE_SCALE_IMAGE)
		# if (os.path.isfile(directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)):
		#    print(' file exists')

		imagedeepneural = None
		faces = None

		imagedeepneural = face_recognition.load_image_file(
			directorytosave + '/faces/' + currentfoldername + '/' + 'resizedimage.' + extension)
		# Find all the faces in the image using the default HOG-based model.
		# This method is fairly accurate, but not as accurate as the CNN model and not GPU accelerated.
		# See also: find_faces_in_picture_cnn.py
		faces = face_recognition.face_locations(imagedeepneural, number_of_times_to_upsample=1, model="cnn")

	# print("I found {} face(s) in this photograph.".format(len(faces)))
	# print(faces)

	lowestx = 0
	highestx = 0
	highesty = 0
	lowesty = 0
	face_file_name = ''
	detectedFacesImage = []
	for f in faces:
		# x, y, w, h = [ v for v in f ]
		# print (' x ' + str(x))
		# print (' y ' + str(y))
		deepneuraltop, deepneuralright, deepneuralbottom, deepneuralleft = f
		x = deepneuralleft
		y = deepneuraltop
		w = deepneuralright - x
		h = deepneuralbottom - y

		# cv2.rectangle(img, (x,y), (x+w,y+h), (255,255,255))

		face_file_name = directorytosave + "/faces/" + currentfoldername + "/face_" + str(x) + '_' + str(
			y) + "." + extension
		sub_face = img[y:y + h, x:x + w]
		cv2.imwrite(face_file_name, sub_face)

		detectedFacesImage.append(face_file_name)

		# lowest of x is must. first value will be lowest
		if lowestx == 0:
			lowestx = x

		if x < lowestx:
			lowestx = x

		if x > highestx:
			highestx = x

		# highest of y is must
		if y > highesty:
			highesty = y

		if lowesty == 0:
			lowesty = y

		if y < lowesty:
			lowesty = y

	print (' lowestx ' + str(lowestx))
	print (' highestx ' + str(highestx))
	print (' highesty ' + str(highesty))
	print (' lowesty ' + str(lowesty))
	print (' height ' + str(height))
	print (' width ' + str(width))
	# once all the lowest and highest value of x is known
	widthavailable = 0
	# if the image width is less then width between faces
	if highestx - lowestx <= requiredw:
		# width available for cropping either side
		widthavailable = requiredw - (highestx - lowestx)
		templowestx = lowestx - (widthavailable / 2)

		# check adding available width makes the x axis negative
		if templowestx < 0:
			lowestx = 0
		else:
			lowestx = templowestx

		temphighestx = highestx + (widthavailable / 2)
		# to avaoid space on left side
		templowestx = lowestx - (widthavailable / 2)

		addtionalwidth = 0
		# if width is greater then the highest of x
		if temphighestx > width:
			addtionalwidth = highestx + (widthavailable / 2) - width
			# add the additional width to the x axis
			lowestx = lowestx - addtionalwidth
			# remove the additional width from the x axis
			highestx = highestx + (widthavailable / 2) - addtionalwidth

		# to avoid left space follwoing condition
		elif templowestx < 0:

			for eachface in detectedFacesImage:
				print(eachface)
				faceimagedetails = cv2.imread(eachface)
				facewidth = (faceimagedetails.shape[1] / 2)
				lowestx = lowestx + facewidth

			# faceimagedetails = cv2.imread(face_file_name)
			# facewidth = (faceimagedetails.shape[1]/2)
			# lowestx = lowestx + facewidth

			lowestx = int(lowestx)
		else:

			for eachface in detectedFacesImage:
				faceimagedetails = cv2.imread(eachface)
				facewidth = (faceimagedetails.shape[1] / 5)
				lowestx = lowestx + facewidth
			lowestx = int(lowestx)

	# check for y axis

	# The face detection only takes face but not the hair .To include the hairs
	if (lowesty - 15) >= 0:
		lowesty = lowesty - 15
	elif (lowesty - 10) >= 0:
		lowesty = lowesty - 10
	else:
		lowesty = 0

	while (hsize - lowesty) < requiredh:
		lowesty -=1

	# return
	sub_face = img[lowesty:lowesty + requiredh, lowestx:lowestx + requiredw]

	# sub_face = img[y:355, x:237]
	try:
		# ts = time.time()
		# os.makedirs(ts)

		crop_file_name = directorytosave + "/faces/" + currentfoldername + "/" + imagename
		cv2.imwrite(crop_file_name, sub_face)
		return crop_file_name
	except OSError:
		pass

	# cv2.imshow(image, img)

	return


# facechop("Pooja Hegde.jpg",220,144)
if __name__ == "__main__":
	if len(sys.argv) == 8:
		facedetectioncrop(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4], sys.argv[5],sys.argv[6], sys.argv[7])
