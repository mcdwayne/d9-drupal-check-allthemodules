from rasa_core.channels.channel import InputChannel
from rasa_core.agent import Agent
from rasa_core.interpreter import RasaNLUInterpreter
from rasa_custom_connector import CustomInput
from generalconfig import Generalconfig
from rasa_nlu.components import ComponentBuilder
from rasa_core.utils import EndpointConfig

builder = ComponentBuilder(use_cache=False)      # will cache components between pipelines (where possible)


nlu_interpreter = RasaNLUInterpreter('./models/nlu/default/weathernlu',builder)
action_endpoint = EndpointConfig(url="http://localhost:5055/webhook")
agent = Agent.load('./models/dialogue', interpreter = nlu_interpreter,action_endpoint = action_endpoint)

input_channel = CustomInput(Generalconfig.websiteurl+'/chatwindow/rasadata',Generalconfig.authtoken, #app verification token
							)

agent.handle_channels([input_channel], 5004, serve_forever=True)