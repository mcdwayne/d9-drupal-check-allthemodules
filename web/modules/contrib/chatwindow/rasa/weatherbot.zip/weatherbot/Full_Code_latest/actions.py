from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet


import re
import requests
import json
import os
from generalconfig import Generalconfig
from array import *

from typing import Dict, Text, Any, List, Union

from rasa_core_sdk import ActionExecutionRejection
from rasa_core_sdk import Tracker
from rasa_core_sdk.executor import CollectingDispatcher
from rasa_core_sdk.forms import FormAction, REQUESTED_SLOT


class Actionimagecrop(FormAction):
	def name(self):
		return 'imagecrop_form'

	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""

		return ["cropimage"]

	def validate(self,
				 dispatcher: CollectingDispatcher,
				 tracker: Tracker,
				 domain: Dict[Text, Any]) -> List[Dict]:
		"""Validate extracted requested slot
			else reject the execution of the form action
		"""
		# extract other slots that were not requested
		# but set by corresponding entity
		slot_values = self.extract_other_slots(dispatcher, tracker, domain)



		# extract requested slot
		slot_to_fill = tracker.get_slot(REQUESTED_SLOT)
		if slot_to_fill:
			slot_values.update(self.extract_requested_slot(dispatcher,
														   tracker, domain))
			if not slot_values:
				# reject form action execution
				# if some slot was requested but nothing was extracted
				# it will allow other policies to predict another action
				#dispatcher.utter_message(((tracker.latest_message)['text']) +' '+ slot_to_fill +' cannot be empty '+REQUESTED_SLOT +' '+ self.name())


					slot_values[slot_to_fill] = ((tracker.latest_message)['text'])



			if slot_to_fill == 'cropimage':
				url = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
								 (tracker.latest_message)['text'])

				if (len(url) >= 1):
					slot_values[slot_to_fill] = url[0]
				else:
					slot_values[slot_to_fill] = None
					dispatcher.utter_message('Enter proper Url')

		# validation succeed, set the slots values to the extracted values
		return [SlotSet(slot, value) for slot, value in slot_values.items()]

	def submit(self,
			   dispatcher: CollectingDispatcher,
			   tracker: Tracker,
			   domain: Dict[Text, Any]) -> List[Dict]:
		"""Define what the form has to do
			after all required slots are filled"""





		if Generalconfig.authtoken is not None:
			headers = {"Auth-token": Generalconfig.authtoken}
		else:
			headers = {}
		try:
			response = requests.post(Generalconfig.websiteurl + '/chatwindow/imagecrop',
									 data={'srcimagepath': tracker.get_slot('cropimage'), 'message': 'Image:',
										   'recipient_id': tracker.sender_id}, headers=headers,
									 verify=False)
			json_data = response.json()
			if json_data['command']:
				os.system( Generalconfig.cvpathpythonVirtbin + ' ' + Generalconfig.Imagefacedetectioncodepath +' ' +  json_data['command'])
			if json_data['clientmessage'] == 'Success':
				dispatcher.utter_message('Image:' + json_data['croppedimageurl'])

				dispatcher.utter_template("utterReplaceCroppedimage",tracker)

				#slot_values = ['cropimage','croppedimageurl']

				slot_values  = {'cropimage': tracker.get_slot('cropimage'), 'croppedimageurl' : json_data['croppedimageurl']}


				#slot_values['cropimage'] = url[0]
				#slot_values['croppedimageurl'] = json_data['croppedimageurl']
				return [SlotSet(slot, value) for slot, value in slot_values.items()]
			else:

				dispatcher.utter_message(json_data['clientmessage'])

		except requests.exceptions.RequestException as e:

			dispatcher.utter_message(e)

		slot_values = {'cropimage': None, 'croppedimageurl': None , 'usercropimage': None}

		# slot_values['cropimage'] = url[0]
		# slot_values['croppedimageurl'] = json_data['croppedimageurl']
		return [SlotSet(slot, value) for slot, value in slot_values.items()]




class ActionReplaceCroppedimage(Action):
	def name(self):
		return 'ActionReplaceCroppedimage'

	def run(self, dispatcher, tracker, domain):

		if tracker.get_slot('usercropimage') == 'no':
			dispatcher.utter_message('Image is not replaced')

		elif tracker.get_slot('usercropimage') == 'yes':
			if Generalconfig.authtoken is not None:
				headers = {"Auth-token": Generalconfig.authtoken}
			else:
				headers = {}
			response = requests.post(Generalconfig.websiteurl + '/chatwindow/replacecroppedimage',
									 data={'cropimage': tracker.get_slot('cropimage'),
										   'croppedimageurl': tracker.get_slot('croppedimageurl'),
										   'recipient_id': tracker.sender_id},
									 headers=headers,
									 verify=False)

			json_data = response.json()

			if json_data['clientmessage'] == 'Success':
				#slot_values = {'cropimage': '', 'croppedimageurl': '','usercropimage':''}
				dispatcher.utter_message('Replaced successfully')
				# [SlotSet(slot, value) for slot, value in slot_values.items()]
				#return [SlotSet(slot, value) for slot, value in slot_values.items()]


		#return [SlotSet("usercropimage", "")]

		slot_values = {'cropimage': None, 'croppedimageurl': None,'usercropimage': None}

		# slot_values['cropimage'] = url[0]
		# slot_values['croppedimageurl'] = json_data['croppedimageurl']
		return [SlotSet(slot, value) for slot, value in slot_values.items()]

class AddblockForm(FormAction):
	"""Example of a custom form action"""

	def name(self):
		# type: () -> Text
		"""Unique identifier of the form"""

		return "addblock_form"

	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""

		return ["blocktitle", "blockdescription", "blockbodycontent","contentregion"]

	def validate(self,
				 dispatcher: CollectingDispatcher,
				 tracker: Tracker,
				 domain: Dict[Text, Any]) -> List[Dict]:
		"""Validate extracted requested slot
			else reject the execution of the form action
		"""
		# extract other slots that were not requested
		# but set by corresponding entity
		slot_values = self.extract_other_slots(dispatcher, tracker, domain)



		# extract requested slot
		slot_to_fill = tracker.get_slot(REQUESTED_SLOT)
		if slot_to_fill:
			slot_values.update(self.extract_requested_slot(dispatcher,
														   tracker, domain))
			if not slot_values:
				# reject form action execution
				# if some slot was requested but nothing was extracted
				# it will allow other policies to predict another action
				#dispatcher.utter_message(((tracker.latest_message)['text']) +' '+ slot_to_fill +' cannot be empty '+REQUESTED_SLOT +' '+ self.name())


					slot_values[slot_to_fill] = ((tracker.latest_message)['text'])



			if slot_to_fill == 'contentregion':


				regions = ['content', 'page_top', 'sidebar_first', 'sidebar_second']

				if tracker.get_slot('contentregion') not in regions:
					slot_values[slot_to_fill] = None

		# validation succeed, set the slots values to the extracted values
		return [SlotSet(slot, value) for slot, value in slot_values.items()]

	def submit(self,
			   dispatcher: CollectingDispatcher,
			   tracker: Tracker,
			   domain: Dict[Text, Any]) -> List[Dict]:
		"""Define what the form has to do
			after all required slots are filled"""
		if Generalconfig.authtoken is not None:
			headers = {"Auth-token": Generalconfig.authtoken}
		else:
			headers = {}

		response = requests.post(Generalconfig.websiteurl + '/chatwindow/addblock',
								 data={'blocktitle': tracker.get_slot('blocktitle'),
									   'blockdescription': tracker.get_slot('blockdescription'),
									   'blockbodycontent': tracker.get_slot('blockbodycontent'),
									   'contentregion': tracker.get_slot('contentregion'),
									   'currentpath': tracker.get_slot('currentpath'),
									   'recipient_id': tracker.sender_id},
								 headers=headers,
								 verify=False)

		print(response.content)

		json_data = response.json()



		if json_data['clientmessage'] == 'Success':
			dispatcher.utter_template('utter_submitcreatedblock', tracker)

			outputmessage = {'message':'','link':{}}
			#outputmessage['message'] = ''
			#outputmessage['link'] = {}
			outputmessage['link'][0] = {}
			outputmessage['link'] [0] ['linktitle'] = 'Edit block'
			outputmessage['link'] [0] ['url'] = json_data["editurl"]
			outputmessage['link'] [0] ['target'] = "_blank"

			outputmessage['link'][1] = {}
			outputmessage['link'] [1] ['linktitle'] = 'Configure Block'
			outputmessage['link'] [1] ['url'] = json_data["configureurlid"]
			outputmessage['link'] [1] ['target'] = "_blank"


			dispatcher.utter_message(json.dumps(outputmessage))




		# utter submit template

		slot_values = {'blocktitle': None, 'blockdescription': None, 'blockbodycontent': None,'contentregion':None}


		return [SlotSet(slot, value) for slot, value in slot_values.items()]



class AddtoSectionForm(FormAction):
	"""Example of a custom form action"""

	def name(self):
		# type: () -> Text
		"""Unique identifier of the form"""

		return "addtosection_form"

	@staticmethod
	def required_slots(tracker: Tracker) -> List[Text]:
		"""A list of required slots that the form has to fill"""

		return ["sectionfieldname", "sectionfieldvalue", "nodepagepathornodeid"]

	def validate(self,
				 dispatcher: CollectingDispatcher,
				 tracker: Tracker,
				 domain: Dict[Text, Any]) -> List[Dict]:
		"""Validate extracted requested slot
			else reject the execution of the form action
		"""
		# extract other slots that were not requested
		# but set by corresponding entity
		slot_values = self.extract_other_slots(dispatcher, tracker, domain)



		# extract requested slot
		slot_to_fill = tracker.get_slot(REQUESTED_SLOT)
		if slot_to_fill:
			slot_values.update(self.extract_requested_slot(dispatcher,
														   tracker, domain))
			if not slot_values:
				# reject form action execution
				# if some slot was requested but nothing was extracted
				# it will allow other policies to predict another action
				#dispatcher.utter_message(((tracker.latest_message)['text']) +' '+ slot_to_fill +' cannot be empty '+REQUESTED_SLOT +' '+ self.name())

				if slot_to_fill == 'nodepagepathornodeid' and tracker.get_slot(slot_to_fill) is None:

					slot_values[slot_to_fill] = ((tracker.latest_message)['text'])
				elif slot_to_fill == 'nodepagepathornodeid':
					slot_values[slot_to_fill] = tracker.get_slot(slot_to_fill)



				if slot_to_fill == 'nodepagepathornodeid' and  slot_values[slot_to_fill] is not None and slot_values[slot_to_fill] != 'terminatetheform' and slot_values[slot_to_fill]!='nodenumber':


					slot_values[slot_to_fill] = ((tracker.latest_message)['text'])


					if Generalconfig.authtoken is not None:
						headers = {"Auth-token": Generalconfig.authtoken}
					else:
						headers = {}

					#check node id or node path exists
					response = requests.post(Generalconfig.websiteurl + '/chatwindow/checknodepagepathornodeid',
											 data={'nodepagepathornodeid': slot_values[slot_to_fill]},
											 headers=headers,
											 verify=False)



					json_data = response.json()



					if json_data['clientmessage'] == 'Success':

						slot_values[slot_to_fill] = json_data['nodepagepathornodeid']
					else:
						dispatcher.utter_message('Could not find the node id. Enter proper node id or node url')
						slot_values[slot_to_fill] = None



		# validation succeed, set the slots values to the extracted values
		return [SlotSet(slot, value) for slot, value in slot_values.items()]

	def submit(self,
			   dispatcher: CollectingDispatcher,
			   tracker: Tracker,
			   domain: Dict[Text, Any]) -> List[Dict]:
		"""Define what the form has to do
			after all required slots are filled"""

		if tracker.get_slot('sectionfieldname') == 'terminatetheform' or tracker.get_slot('nodepagepathornodeid') == 'nodenumber' :
			dispatcher.utter_template('utter_greet', tracker)
		else:
			if Generalconfig.authtoken is not None:
				headers = {"Auth-token": Generalconfig.authtoken}
			else:
				headers = {}

			response = requests.post(Generalconfig.websiteurl + '/chatwindow/addtosection',
									 data={'sectionfieldname': tracker.get_slot('sectionfieldname'),
										   'nodepagepathornodeid': tracker.get_slot('nodepagepathornodeid'),
										   'sectionfieldvalue': tracker.get_slot('sectionfieldvalue'),
										   'recipient_id': tracker.sender_id},
									 headers=headers,
									 verify=False)

			#print(response.content)
			json_data = response.json()

			if json_data['clientmessage'] == 'Success':
				dispatcher.utter_message("Added Successfully.Refresh the page to see the result")
			else:
				dispatcher.utter_message(json_data['errormessage'])


		slot_values = {'sectionfieldname': None, 'sectionfieldvalue': None, 'nodepagepathornodeid': None}

		return [SlotSet(slot, value) for slot, value in slot_values.items()]
		#return [SlotSet(slot, value) for slot, value in slot_values.items()]





