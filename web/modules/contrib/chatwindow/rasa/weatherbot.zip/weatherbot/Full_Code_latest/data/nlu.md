## intent:addtopagesection
- add to section
- section

## intent:entered_blockbodycontent
- test description
- content is [Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.](blockbodycontent:lorem ipsum has been the industry 's standard dummy text ever since the 1500s , when an unknown printer took a galley of type and scrambled it to make a type specimen book .)
- content is [Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.](blockbodycontent:lorem ipsum has been the industry 's standard dummy text ever since the 1500s , when an unknown printer took a galley of type and scrambled it to make a type specimen book .)

## intent:entered_blockdescription
- test description asdf asdfasd asdfasdfasd
- test description
- description is [Lorem Ipsum is simply dummy text](blockdescription:lorem ipsum is simply dummy text)
- description is [Lorem Ipsum is simply dummy text](blockdescription:lorem ipsum is simply dummy text)
- test description

## intent:entered_blocktitle
- asdfasd asdfasdfasdfasd sdfasdf
- [6 NEW RESTAURANTS TO TRY OUT IN MUMBAI](blocktitle)
- title is [What is Lorem Ipsum?](blocktitle:What is lorem ipsum?)
- title is [What is Lorem Ipsum?](blocktitle:what is lorem ipsum?)
- test title

## intent:entered_cropimagepath
- https://www.yourdomain.com/d86versions/sites/default/files/styles/medium/public/2019-03/node_img82918_3_135.jpg?itok=hkzPpQbq
- https://www.externaldomain.com/sdfasdfsdf06252811_mediaitemwerter.jpg
- https://www.externaldomain.com/asdfsdf106252811_mediaitem106qwreqw.jpg

## intent:entered_nodepagepathornodeid
- 1234

## intent:goodbye
- cu
- good by
- cee you later
- good night
- good afternoon
- bye
- goodbye
- have a nice day
- see you around
- bye bye
- see you later

## intent:greet
- hey
- hello
- hi
- hello there
- good morning
- good evening
- moin
- hey there
- let's go
- hey dude
- goodmorning
- goodevening
- good afternoon
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi

## intent:request_addblock
- insert block
- add block
- add block
- add block
- insert block
- test block content

## intent:request_cropimagepath
- image crop
- crop image

## intent:selected_contentregion
- /selected_contentregion[{"contenregion":"sidebar_firstdfghdfg"}](contenregion:sidebar_firstdfghdfg)
- /selected_contentregion[{"contenregion":"sidebar_second"}](contenregion:sidebar_second)

## intent:selectpagesection
- add to section

## intent:selectsections
- /selectsections[{"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue"}](sectionfieldname:fieldname)[{"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue"}](sectionfieldvalue:fieldvalue)
- /selectsections[{"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue","nodepagepathornodeid":"nodenumber"}](sectionfieldname:fieldname)[{"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue","nodepagepathornodeid":"nodenumber"}](sectionfieldvalue:fieldvalue)[{"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue","nodepagepathornodeid":"nodenumber"}](nodepagepathornodeid:nodenumber)

## intent:yesReplaceCroppedimage
- /yesReplaceCroppedimage[{"usercropimage":"no"}](usercropimage:no)

## synonym:What is lorem ipsum?
- What is Lorem Ipsum?

## synonym:fieldvalue
- {"sectionfieldname":"fieldname","sectionfieldvalue":"fieldvalue"}

## synonym:lorem ipsum has been the industry 's standard dummy text ever since the 1500s , when an unknown printer took a galley of type and scrambled it to make a type specimen book .
- Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

## synonym:lorem ipsum is simply dummy text
- Lorem Ipsum is simply dummy text

## synonym:no
- {"usercropimage":"no"}

## synonym:sidebar_firstdfghdfg
- {"contenregion":"sidebar_firstdfghdfg"}

## synonym:sidebar_second
- {"contenregion":"sidebar_second"}
