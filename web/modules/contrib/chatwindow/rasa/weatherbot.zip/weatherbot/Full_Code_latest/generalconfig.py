class Generalconfig():
	websiteurl = "https://www.yourdomain.com/d86versions"
	authtoken = '123rdertdfgssrasa$dary&E'
	cvpathpythonVirtbin = '/user/.virtualenvs/cv/bin/python3.4'
	Imagefacedetectioncodepath = '/home/user/rasa/weatherbot/Full_Code_latest/opencv/imagecrop.py'
