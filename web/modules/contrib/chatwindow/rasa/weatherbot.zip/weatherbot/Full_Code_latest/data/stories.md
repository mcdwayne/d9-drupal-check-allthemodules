## Generated Story -Defualt
* greet
    - utter_greet
## Generated Story -8438523455234273393
* greet
    - utter_greet
* request_addblock
    - addblock_form
    - form{"name": "addblock_form"}
    - slot{"requested_slot": "blocktitle"}
* form: entered_blocktitle
    - form: addblock_form
    - slot{"blocktitle": "test title"}
    - slot{"requested_slot": "blockdescription"}
* form: entered_blockdescription
    - form: addblock_form
    - slot{"blockdescription": "test description"}
    - slot{"requested_slot": "blockbodycontent"}
* form: request_addblock
    - form: addblock_form
    - slot{"blockbodycontent": "test block content"}
    - slot{"requested_slot": "contentregion"}
* form: selected_contentregion{"contenregion": "sidebar_firstdfghdfg"}
    - slot{"contentregion": "sidebar_firstdfghdfg"}
    - form: addblock_form
    - slot{"contentregion": null}
    - slot{"requested_slot": "contentregion"}
* form: selected_contentregion{"contentregion": "sidebar_second"}
    - slot{"contentregion": "sidebar_second"}
    - form: addblock_form
    - slot{"contentregion": "sidebar_second"}
    - slot{"blocktitle": null}
    - slot{"blockdescription": null}
    - slot{"blockbodycontent": null}
    - slot{"contentregion": null}
    - form{"name": null}
    - slot{"requested_slot": null}
## Generated Story - without greet
* request_addblock
    - addblock_form
    - form{"name": "addblock_form"}
    - slot{"requested_slot": "blocktitle"}
* form: entered_blocktitle
    - form: addblock_form
    - slot{"blocktitle": "test title"}
    - slot{"requested_slot": "blockdescription"}
* form: entered_blockdescription
    - form: addblock_form
    - slot{"blockdescription": "test description"}
    - slot{"requested_slot": "blockbodycontent"}
* form: request_addblock
    - form: addblock_form
    - slot{"blockbodycontent": "test block content"}
    - slot{"requested_slot": "contentregion"}
* form: selected_contentregion{"contenregion": "sidebar_firstdfghdfg"}
    - slot{"contentregion": "sidebar_firstdfghdfg"}
    - form: addblock_form
    - slot{"contentregion": null}
    - slot{"requested_slot": "contentregion"}
* form: selected_contentregion{"contentregion": "sidebar_second"}
    - slot{"contentregion": "sidebar_second"}
    - form: addblock_form
    - slot{"contentregion": "sidebar_second"}
    - slot{"blocktitle": null}
    - slot{"blockdescription": null}
    - slot{"blockbodycontent": null}
    - slot{"contentregion": null}
    - form{"name": null}
    - slot{"requested_slot": null}
## Generated Story 5735754541964460355
* greet
    - utter_greet
* request_cropimagepath
    - imagecrop_form
    - form{"name": "imagecrop_form"}
    - slot{"requested_slot": "cropimage"}
* form: entered_cropimagepath
    - form: imagecrop_form
    - slot{"cropimage": "https://www.yourdomain.com/d86versions/sites/default/files/styles/medium/public/2019-03/asdf82918_3_135.jpg?itok=hkyPpQbe"}
    - slot{"cropimage": "https://www.yourdomain.com/d86versions/sites/default/files/styles/medium/public/2019-03/node_img82918_3_135.jpg?itok=hkzPpQbq"}
    - slot{"croppedimageurl": "https://www.yourdomain.com/d86versions/sites/default/files/opencv/faces/1554121238/asdfasf2918_3_asdf.jpg"}
    - form{"name": null}
    - slot{"requested_slot": null}
* yesReplaceCroppedimage{"usercropimage": "no"}
    - slot{"usercropimage": "no"}
    - ActionReplaceCroppedimage
## Generated Story -7865043052294934466
* greet
    - utter_greet
* request_cropimagepath
    - imagecrop_form
    - form{"name": "imagecrop_form"}
    - slot{"requested_slot": "cropimage"}
* form: entered_cropimagepath
    - form: imagecrop_form
    - form: imagecrop_form
    - slot{"requested_slot": "cropimage"}
* form: entered_cropimagepath
    - form: imagecrop_form
    - slot{"cropimage": "https://www.externaldomain.com/asdf6252811_mediaitemasdf.jpg"}
    - form{"name": null}
    - slot{"requested_slot": null}
## Generated Story without greet
* request_cropimagepath
    - imagecrop_form
    - form{"name": "imagecrop_form"}
    - slot{"requested_slot": "cropimage"}
* form: entered_cropimagepath
    - form: imagecrop_form
    - slot{"cropimage": "https://www.yourdomain.com/d86versions/sites/default/files/styles/medium/public/2019-03/qwerds82918_3_135.jpg?itok=hkzPpQsa"}
    - slot{"cropimage": "https://www.yourdomain.com/d86versions/sites/default/files/styles/medium/public/2019-03/gsdfg82918_3_135.jpg?itok=hkzPpQbe"}
    - slot{"croppedimageurl": "https://www.yourdomain.com/d86versions/sites/default/files/opencv/faces/1554121238/tyery82918_3_135.jpg"}
    - form{"name": null}
    - slot{"requested_slot": null}
* yesReplaceCroppedimage{"usercropimage": "no"}
    - slot{"usercropimage": "no"}
    - ActionReplaceCroppedimage



## Generated Story -9154970221021909830
* greet
    - utter_greet
* addtopagesection
    - addtosection_form
    - form{"name": "addtosection_form"}
    - slot{"requested_slot": "sectionfieldname"}
* form: selectsections{"sectionfieldname": "fieldname", "sectionfieldvalue": "fieldvalue"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"sectionfieldvalue": "fieldvalue"}
    - form: addtosection_form
    - slot{"sectionfieldvalue": "fieldvalue"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"requested_slot": "nodepagepathornodeid"}
* form: entered_nodepagepathornodeid
    - form: addtosection_form
    - slot{"nodepagepathornodeid": "1234"}
    - form{"name": null}
    - slot{"requested_slot": null}
    - addtosection_form
    - form{"name": "addtosection_form"}
    - form{"name": null}
    - slot{"requested_slot": null}

## Generated Story 5985807817325220504
* greet
    - utter_greet
* addtopagesection
    - addtosection_form
    - form{"name": "addtosection_form"}
    - slot{"requested_slot": "sectionfieldname"}
* form: selectsections{"sectionfieldname": "fieldname", "sectionfieldvalue": "fieldvalue", "nodepagepathornodeid": "nodenumber"}
    - slot{"nodepagepathornodeid": "nodenumber"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"sectionfieldvalue": "fieldvalue"}
    - form: addtosection_form
    - slot{"sectionfieldvalue": "fieldvalue"}
    - slot{"nodepagepathornodeid": "nodenumber"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"sectionfieldname": null}
    - slot{"sectionfieldvalue": null}
    - slot{"nodepagepathornodeid": null}
    - form{"name": null}
    - slot{"requested_slot": null}
## without Greet
* addtopagesection
    - addtosection_form
    - form{"name": "addtosection_form"}
    - slot{"requested_slot": "sectionfieldname"}
* form: selectsections{"sectionfieldname": "fieldname", "sectionfieldvalue": "fieldvalue", "nodepagepathornodeid": "nodenumber"}
    - slot{"nodepagepathornodeid": "nodenumber"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"sectionfieldvalue": "fieldvalue"}
    - form: addtosection_form
    - slot{"sectionfieldvalue": "fieldvalue"}
    - slot{"nodepagepathornodeid": "nodenumber"}
    - slot{"sectionfieldname": "fieldname"}
    - slot{"sectionfieldname": null}
    - slot{"sectionfieldvalue": null}
    - slot{"nodepagepathornodeid": null}
    - form{"name": null}
    - slot{"requested_slot": null}

