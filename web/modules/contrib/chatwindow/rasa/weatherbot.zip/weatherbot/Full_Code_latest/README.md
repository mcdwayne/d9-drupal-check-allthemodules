# Weatherbot Tutorial (using the latest release of Rasa NLU and Rasa Core)

Rasa NLU and Rasa Core devs are doing an amazing job improving both of these libraries which results in code changes for one method or another. In fact, since I recorded a Wetherbot tutorial,
there were quite a few changes which were introduced to Rasa NLU and Rasa Core. For this reason I created this directory which will contain Weatherbot code, compatible with the latest
releases of Rasa NLU and Rasa Core. I will do my best to keep it up-to-date, but if you encounter any issues with using the code, please raise an issue or drop me a message :)

Latest code update: 19/05/2018

Latest compatible Rasa NLU version: 0.12.3

Latest compatible Rasa Core version: 0.9.0a3 (master)