<?php

namespace Drupal\paldesk\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides the path admin overview form.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'paldesk_admin_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['paldesk.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('paldesk.settings');

    $form['api_key'] = [
      '#type' => 'textfield',
      '#title' => t('Paldesk Live Chat & Support API KEY'),
      '#default_value' => $config->get('api_key'),
      '#description' => t('API key is unique for Paldesk Account.
             To fill API key field, register or login to Paldesk app 
             (<br/><a href=":paldesk_url">Paldesk Site</a>), 
             and go to \'Administration\' menu. 
             Expand Widget (\'+\') or click on \'Edit\' and copy API\'s key 
             from \'CMS integration\' tab to identify the widget.
             Paste API key here and Save changes.
            ',
         [
           ':paldesk_url' =>
           'https://www.paldesk.com',
         ]),
      '#size' => 70,
      '#maxlength' => 70,
      '#required' => TRUE,
    ];

    $form['visibility'] = [
      '#type' => 'radios',
      '#title' => t('Show Paldesk Chat widget on specific pages'),
      '#options' => [
        PALDESK_BLACKLIST_MODE => t('Hide for the listed pages'),
        PALDESK_WHITELIST_MODE => t('Show for the listed pages'),
      ],
      '#default_value' => $config->get('visibility'),
    ];
    $form['pages'] = [
      '#type' => 'textarea',
      '#title' => '<span class="visually-hidden">' . t('Pages') . '</span>',
      '#default_value' => _paldesk_array_to_string($config->get('pages')),
      '#description' => t("Specify pages by using their paths. 
            Enter one path per line. The '*' character is a wildcard. 
            Example paths are %user for the current user's page 
            and %user-wildcard for every user page. %front is the front page.",
        [
          '%user' => '/user',
          '%user-wildcard' => '/user/*',
          '%front' =>
          '<front>',
        ]),
    ];
    $form['roles'] = [
      '#type' => 'checkboxes',
      '#title' => t('Hide Paldesk Chat widget for specific roles'),
      '#options' => array_map('\Drupal\Component\Utility\Html::escape', user_role_names()),
      '#default_value' => $config->get('roles'),
      '#description' => t('Hide Paldesk Chat widget only for the selected
            role(s). If none of the roles are selected, all roles will have the 
            widget. Otherwise, any roles selected here will NOT have the widget.'
      ),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    $this->config('paldesk.settings')
      ->set('api_key', $values['api_key'])
      ->set('visibility', $values['visibility'])
      ->set('pages', _paldesk_string_to_array($values['pages']))
      ->set('roles', array_filter($values['roles']))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
